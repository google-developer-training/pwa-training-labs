require('file-loader?name=[name].[ext]!./index.html');
require('file-loader?name=css/[name].[ext]!./css/main.css');
require('file-loader?name=images/[name].[ext]!./images/cockatoos_medium.jpg');
